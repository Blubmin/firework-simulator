Ian Meeder
impeder

The mesh was initially created using Cosmic Blobs software developed by Dassault Systemes SolidWorks Corp.

Stage 3 complete - only single animation